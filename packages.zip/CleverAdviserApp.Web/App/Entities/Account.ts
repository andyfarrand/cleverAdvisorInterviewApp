﻿module App {
    export interface Account {
        accountId: number;
        investorId: string;
        amountHeld: number;
        type: string;
        dateCreated: string;
    }


}